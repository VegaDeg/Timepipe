# Timepipe
 Timepipe is a package that visualize running time in realtime systems.

 This package is intended for high speed systems where all kinds of events happends and temporal relationship is important.
 
 Create an event in advance, check it in your code at where you care about when something happened. You can also attach it as a part of a pipeline, so a set of events could be visualized conveniently and nicely.

To install, simply run:
pip install timepipe